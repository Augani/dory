import Testing
@Test func optionalDiskByteComparison() throws {
    let value: UInt64? = 103_079_215_104
    let original = value == 96 * 1_024 * 1_024 * 1_024
    #expect(original)
    #expect(value == 96 * 1_024 * 1_024 * 1_024)
    let bytes = try #require(value)
    let expected: UInt64 = 96 * 1_024 * 1_024 * 1_024
    #expect(bytes == expected)
}
