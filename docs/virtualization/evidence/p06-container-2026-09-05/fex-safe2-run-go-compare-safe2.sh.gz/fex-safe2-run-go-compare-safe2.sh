#!/usr/bin/env bash
set -u
LOG=/work/go-baseline-safe2-compare.log
: > "$LOG"
echo "go_compare started_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)" | tee -a "$LOG"
run_one() {
  variant="$1"; cand="$2"; label="$3"; envspec="$4"; bin="$5"; limit="$6"
  app="/tmp/fexappdata-go-${variant}-${label}-1788671500"
  sock="/tmp/fex-go-${variant}-${label}-1788671500.sock"
  python3 - <<'PY' "$app" "$sock"
import pathlib, shutil, sys
for raw in sys.argv[1:]:
    p=pathlib.Path(raw)
    if p.is_dir(): shutil.rmtree(p)
    elif p.exists(): p.unlink()
PY
  mkdir -p "$app"
  export FEX_APP_DATA_LOCATION="$app"
  export FEX_SERVERSOCKETPATH="$sock"
  export FEX_SERVER_PATH="$cand/FEXServer"
  out="/tmp/go-${variant}-${label}.out"
  err="/tmp/go-${variant}-${label}.err"
  echo | tee -a "$LOG"
  echo "## $variant $label env={$envspec}" | tee -a "$LOG"
  sha256sum "$cand/FEX" | awk '{print "fex_sha256="$1}' | tee -a "$LOG"
  sha256sum "$cand/FEXServer" | awk '{print "fexserver_sha256="$1}' | tee -a "$LOG"
  sha256sum "$bin" | awk '{print "probe_sha256="$1}' | tee -a "$LOG"
  start=$(date +%s)
  if [ "$envspec" = default ]; then
    timeout "$limit" "$cand/FEX" "$bin" >"$out" 2>"$err"
  elif [ "$envspec" = gmp4 ]; then
    GOMAXPROCS=4 timeout "$limit" "$cand/FEX" "$bin" >"$out" 2>"$err"
  elif [ "$envspec" = preemptoff ]; then
    GODEBUG=asyncpreemptoff=1 timeout "$limit" "$cand/FEX" "$bin" >"$out" 2>"$err"
  elif [ "$envspec" = gmp4_preemptoff ]; then
    GOMAXPROCS=4 GODEBUG=asyncpreemptoff=1 timeout "$limit" "$cand/FEX" "$bin" >"$out" 2>"$err"
  fi
  rc=$?
  end=$(date +%s)
  echo "rc=$rc elapsed=$((end-start))s out_bytes=$(wc -c <"$out") err_bytes=$(wc -c <"$err")" | tee -a "$LOG"
  if [ -s "$out" ]; then echo 'stdout_head<<EOF' | tee -a "$LOG"; sed -n '1,20p' "$out" | tee -a "$LOG"; echo 'EOF' | tee -a "$LOG"; fi
  if [ -s "$err" ]; then echo 'stderr_tail<<EOF' | tee -a "$LOG"; tail -50 "$err" | tee -a "$LOG"; echo 'EOF' | tee -a "$LOG"; fi
}
for variant in shipped safe2; do
  if [ "$variant" = shipped ]; then cand=/candidate-shipped; else cand=/candidate-safe2; fi
  run_one "$variant" "$cand" regexpmini_default default /go-probes/regexpmini-amd64-sysrip 20s
  run_one "$variant" "$cand" regexpstress_default default /go-probes/regexpstress-amd64-unstripped-sysrip 20s
  run_one "$variant" "$cand" regexpstress_gmp4 gmp4 /go-probes/regexpstress-amd64-unstripped-sysrip 20s
  run_one "$variant" "$cand" regexpstress_preemptoff preemptoff /go-probes/regexpstress-amd64-unstripped-sysrip 90s
  run_one "$variant" "$cand" regexpmini_preemptoff preemptoff /go-probes/regexpmini-amd64-sysrip 20s
done
echo | tee -a "$LOG"
echo "ended_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)" | tee -a "$LOG"
