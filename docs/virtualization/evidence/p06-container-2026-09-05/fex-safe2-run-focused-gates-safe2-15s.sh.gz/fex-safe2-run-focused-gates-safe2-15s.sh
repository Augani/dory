#!/usr/bin/env bash
set -u
CAND=/candidate-hostaltstack-safe2-1788671500
PROBES=/probes
LOG=/work/focused-gates.log
: > "$LOG"
echo "focused_gates started_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)" | tee -a "$LOG"
sha256sum "$CAND/FEX" | awk '{print "fex_sha256="$1}' | tee -a "$LOG"
sha256sum "$CAND/FEXServer" | awk '{print "fexserver_sha256="$1}' | tee -a "$LOG"
echo | tee -a "$LOG"
failures=()
run_group() {
  label="$1"; bin="$2"; expect="$3"; count="$4"; limit="$5"
  echo "## $label $(basename "$bin") expect_rc=$expect" | tee -a "$LOG"
  sha256sum "$bin" | awk '{print "probe_sha256="$1}' | tee -a "$LOG"
  i=1
  while [ "$i" -le "$count" ]; do
    app="/tmp/fexappdata-hostaltstack-safe2-${label}-${i}-1788671500"
    sock="/tmp/fex-hostaltstack-safe2-${label}-${i}-1788671500.sock"
    python3 - <<'PY' "$app" "$sock"
import pathlib, shutil, sys
for raw in sys.argv[1:]:
    p=pathlib.Path(raw)
    if p.is_dir(): shutil.rmtree(p)
    elif p.exists(): p.unlink()
PY
    mkdir -p "$app"
    export FEX_APP_DATA_LOCATION="$app"
    export FEX_SERVERSOCKETPATH="$sock"
    export FEX_SERVER_PATH="$CAND/FEXServer"
    out="/tmp/focused-hostaltstack-safe2-${label}.${i}.out"
    err="/tmp/focused-hostaltstack-safe2-${label}.${i}.err"
    start_ns=$(date +%s%N)
    timeout "$limit" "$CAND/FEX" "$bin" >"$out" 2>"$err"
    rc=$?
    end_ns=$(date +%s%N)
    elapsed=$(awk -v s="$start_ns" -v e="$end_ns" 'BEGIN { printf "%.3f", (e-s)/1000000000 }')
    ok=0; [ "$rc" -eq "$expect" ] && ok=1
    echo "iter=$i rc=$rc ok=$ok elapsed=$elapsed" | tee -a "$LOG"
    if [ -s "$out" ]; then echo 'stdout<<EOF' | tee -a "$LOG"; sed -n '1,20p' "$out" | tee -a "$LOG"; echo 'EOF' | tee -a "$LOG"; fi
    if [ -s "$err" ]; then echo 'stderr_tail<<EOF' | tee -a "$LOG"; tail -40 "$err" | tee -a "$LOG"; echo 'EOF' | tee -a "$LOG"; fi
    if [ "$ok" -ne 1 ]; then failures+=("$label.$i rc=$rc expect=$expect"); break; fi
    i=$((i+1))
  done
  echo | tee -a "$LOG"
}
run_group minimal-exit60 "$PROBES/minimal-exit60-amd64" 60 5 5s
run_group v6-original "$PROBES/pushpop-oneshot-v6-amd64" 0 5 15s
run_group v6-marker "$PROBES/pushpop-oneshot-v6-marker-amd64" 0 3 10s
run_group v6-exit-group "$PROBES/pushpop-oneshot-v6-exit-group-amd64" 0 3 15s
run_group v7-nosignal "$PROBES/pushpop-oneshot-v7-nosignal-amd64" 0 3 5s
run_group v7-observe-noedit "$PROBES/pushpop-oneshot-v7-observe_noedit-amd64" 0 3 15s
run_group sig-roundtrip "$PROBES/sigframe-roundtrip-fixed-amd64" 0 3 5s
run_group change-rip-exit "$PROBES/change_rip_exit-amd64" 0 3 5s
run_group change-rip-ret-same-rsp "$PROBES/change_rip_ret_same_rsp-amd64" 0 3 5s
run_group change-rip-rsp-ret "$PROBES/change_rip_rsp_ret-amd64" 0 3 5s
if [ "${#failures[@]}" -eq 0 ]; then echo 'failures=[]' | tee -a "$LOG"; else printf 'failures=[' | tee -a "$LOG"; printf '%s;' "${failures[@]}" | tee -a "$LOG"; printf ']\n' | tee -a "$LOG"; fi
echo "ended_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)" | tee -a "$LOG"
[ "${#failures[@]}" -eq 0 ]
